package com.example.nevihationapplication;

public class ItemModelSub {
    private String names;
    private int nums;

    public ItemModelSub(String names, int nums) {
        this.names = names;
        this.nums = nums;
    }

    public String getNames() {
        return names;
    }

    public void setNames(String names) {
        this.names = names;
    }

    public int getNums() {
        return nums;
    }

    public void setNums(int nums) {
        this.nums = nums;
    }
}
